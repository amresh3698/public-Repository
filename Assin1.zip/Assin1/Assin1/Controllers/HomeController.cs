﻿using Assin1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assin1.Controllers
{
   

    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;
        public HomeController(ApplicationDbContext db)
        {
            _db = db;
        }
        public async Task<IActionResult> Index(string searchString)
        {
            IEnumerable<Emprecord> obj = _db.Emprecords;
            var movies = from m in _db.Emprecords
                         select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                movies = movies.Where(s => s.Name!.Contains(searchString));
            }

            return View(await movies.ToListAsync());
            //return View(await Book.ToListAsync());
        }
        [HttpPost]
        public string Index(string searchString, bool notUsed)
        {
            return "From [HttpPost]Index: filter on " + searchString;
        }
        //Get
        public IActionResult Create()
        {
            return View();
        }

        //post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Emprecord book)
        {
            if (book.Name == book.LastName.ToString())
            {
                ModelState.AddModelError("CustomError", "The DisplayOrder  cannot Match the Name");
            }
            if (ModelState.IsValid)
            {

                _db.Emprecords.Add(book);
                _db.SaveChanges();
                ViewBag.message = "Add sucessfuly";
                return RedirectToAction("Index");
            }
            return View(book);
        }

        //Get
        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var bookdb = _db.Emprecords.Find(id);
            // var bookdbFirst = _db.Books.FirstOrDefault(u => u.Id == id);
            // var bookdbFi = _db.Books.SingleOrDefault(u => u.Id == id);

            if (bookdb == null)
            {
                return NotFound();
            }
            return View(bookdb);
        }

        //post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Emprecord book)
        {
            if (book.Name == book.LastName.ToString())
            {
                ModelState.AddModelError("CustomError", "The DisplayOrder  cannot Match the Name");
            }
            if (ModelState.IsValid)
            {

                _db.Emprecords.Update(book);
                _db.SaveChanges();
                return RedirectToAction("Index");
                ViewBag.message = "Record Updated ";
            }
            return View(book);
        }
        //get
        public IActionResult Delete(int? id)
        {
            var bookdb = _db.Emprecords.Find(id);
            return View(bookdb);
        }
        [HttpPost]
        public IActionResult Delete(Emprecord book)
        {
            if (ModelState.IsValid)
            {
                _db.Emprecords.Remove(book);
                _db.SaveChanges();
                return RedirectToAction("index");
            }
            return View(book);
        }
    }
}
