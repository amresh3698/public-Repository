﻿using Assin1.Models;
using Assin1.Viewmodel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assin1.Controllers
{
    public class NewController : Controller
    {
        private readonly ApplicationDbContext _db;
        public NewController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult List()
        {
            List<Emprecord> emprecords = _db.Emprecords
                .Include(c=>c.Statename)
                .Include(cy=>cy.City)
                .ToList();
            return View(emprecords);
        }
        public IActionResult Create()
        {
            EmpCreatemodel empCreatemodel = new EmpCreatemodel();
            empCreatemodel.Emprecord = new Emprecord();
            List<SelectListItem> Statenames = _db.Statenames.OrderBy(n => n.State).Select(n => new SelectListItem { Value = n.Stateid, Text = n.State }).ToList();
            empCreatemodel.Statenames = Statenames;
            empCreatemodel.Citys = new List<SelectListItem>();
            List<SelectListItem> Cities = _db.cities.OrderBy(n => n.Cityname).Select(n => new SelectListItem { Value = n.CityId, Text = n.Cityname }).ToList();
            return View(empCreatemodel);
           
        }
        public IActionResult Save(EmpCreatemodel empCreatemodel)
        {
            _db.Add(empCreatemodel.Emprecord);
            _db.SaveChanges();
            return RedirectToAction("List");
        }
        [HttpGet]
        public IActionResult GetCities()
        {
            return View();
        }
        [HttpPost]
        public IActionResult GetCities(string Stateid)
        {
            if (!string.IsNullOrWhiteSpace(Stateid) && Stateid.Length==2)
            {
                List<SelectListItem> citiessal = _db.cities.Where(c => c.StateId == Stateid).OrderBy(n => n.Cityname).Select(n => new SelectListItem { Value = n.CityId, Text = n.Cityname }).ToList();
                return Json(citiessal);
            }
            return null;
        }
    }
}
