﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Assin1.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Statenames",
                columns: table => new
                {
                    Stateid = table.Column<string>(nullable: false),
                    State = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Statenames", x => x.Stateid);
                });

            migrationBuilder.CreateTable(
                name: "cities",
                columns: table => new
                {
                    CityId = table.Column<string>(nullable: false),
                    StateId = table.Column<string>(nullable: true),
                    Cityname = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cities", x => x.CityId);
                    table.ForeignKey(
                        name: "FK_cities_Statenames_StateId",
                        column: x => x.StateId,
                        principalTable: "Statenames",
                        principalColumn: "Stateid",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Emprecords",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: false),
                    LastName = table.Column<string>(nullable: true),
                    DOB = table.Column<DateTime>(nullable: false),
                    HomeTownAddress = table.Column<string>(nullable: false),
                    Qualification = table.Column<string>(nullable: true),
                    TYE = table.Column<int>(nullable: false),
                    TME = table.Column<int>(nullable: false),
                    Salary = table.Column<int>(nullable: false),
                    Stateid = table.Column<string>(nullable: false),
                    Cityid = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Emprecords", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Emprecords_cities_Cityid",
                        column: x => x.Cityid,
                        principalTable: "cities",
                        principalColumn: "CityId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Emprecords_Statenames_Stateid",
                        column: x => x.Stateid,
                        principalTable: "Statenames",
                        principalColumn: "Stateid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_cities_StateId",
                table: "cities",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_Emprecords_Cityid",
                table: "Emprecords",
                column: "Cityid");

            migrationBuilder.CreateIndex(
                name: "IX_Emprecords_Stateid",
                table: "Emprecords",
                column: "Stateid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Emprecords");

            migrationBuilder.DropTable(
                name: "cities");

            migrationBuilder.DropTable(
                name: "Statenames");
        }
    }
}
