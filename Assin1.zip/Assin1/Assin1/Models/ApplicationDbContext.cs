﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assin1.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
        {

        }
        public virtual DbSet<Emprecord> Emprecords { get; set; }
        public virtual   DbSet<Statename> Statenames { get; set; }
        public virtual DbSet<City> cities { get; set; }
    }
    //public class Statename
    //{
    //    public int StateId { get; set; }
    //    public string StateName { get; set; }
       
    //}

    //public class City
    //{
    //    public int CityId { get; set; }
    //    public string CityName { get; set; }
    //    public int StateId { get; set; }
    //}
}
