﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Assin1.Models
{
    public class City
    {
        public string CityId { get; set; }
        [ForeignKey("Statename")]
        public string StateId { get; set; }
        [Required]
        public String Cityname { get; set; }

        public virtual Statename Statename { get; set; }

    }
}
