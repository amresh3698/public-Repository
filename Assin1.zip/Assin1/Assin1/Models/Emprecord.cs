﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Assin1.Models
{
    public class Emprecord
    {
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        public string LastName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        //[Required]
        //public string HomeTownCity { get; set; }
        //[Required]
        //public String HomeTownState { get; set; }
        [Required]
        public string HomeTownAddress { get; set; }

        public string Qualification { get; set; }
        [Required]
        public int TYE { get; set; }
        [Required]
        public int TME { get; set; }
        [Required]
        public int Salary { get; set; }
        public Emprecord()
        {
            TYE = 0;
            TME = 0;
            Salary = 0;


        }
        [Required]
        [ForeignKey("Statename")]
        [DisplayName("Statename")]
        public  string Stateid { get; set; }
        public virtual Statename Statename { get; set; }

        [Required]
        [ForeignKey("City")]
        [DisplayName("City")]
        public string Cityid { get; set; }
        public virtual City City { get; set; }


    }
}
