﻿using Assin1.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assin1.Viewmodel
{
    public class EmpCreatemodel
    {
        public Emprecord Emprecord { get; set; }
        public IEnumerable<SelectListItem> Statenames { get; set; }
        public IEnumerable<SelectListItem> Citys { get; set; }
    }
}
