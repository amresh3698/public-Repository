﻿<script type="text/javascript">
    $(function () {
        $("select").each(function () {
            if ($(this).find("option").length <= 1) {
                $(this).attr("disabled", "disabled");
            }
        });

    $("select").change(function () {
                var value = 0;
    if ($(this).val() != "") {
        value = $(this).val();
                }
    var id = $(this).attr("id");
    $.ajax({
        type: "POST",
    url: "/Home/AjaxMethod",
    data: {value: value, type: id },
    success: function (response) {
                        switch (id) {
                            case "ddlCountries":
    DisableDropDown("#ddlStates");
    DisableDropDown("#ddlCities");
    PopulateDropDown("#ddlStates", response.States);
    break;
    case "ddlStates":
    DisableDropDown("#ddlCities");
    PopulateDropDown("#ddlCities", response.Cities);
    break;
                        }
                    },
    failure: function (response) {
        alert(response.responseText);
                    },
    error: function (response) {
        alert(response.responseText);
                    }
                });
            });

    if ($("#ddlCountries").val() != "" && $("#ddlStates").val() != "" && $("#ddlCities").val() != "") {
                var message = "Country: " + $("#ddlCountries option:selected").text();
    message += "\nState: " + $("#ddlStates option:selected").text();
    message += "\nCity: " + $("#ddlCities option:selected").text();
    alert(message);
            }
        });

    function DisableDropDown(dropDownId) {
        $(dropDownId).attr("disabled", "disabled");
    $(dropDownId).empty().append('<option selected="selected" value="0">Please select</option>');
        }

    function PopulateDropDown(dropDownId, list) {
            if (list != null && list.length > 0) {
        $(dropDownId).removeAttr("disabled");
    $.each(list, function () {
        $(dropDownId).append($("<option></option>").val(this['Value']).html(this['Text']));
                });
            }
        }
</script>